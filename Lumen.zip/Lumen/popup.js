document.addEventListener('DOMContentLoaded', () => {
    let currentEngine = 'google';

    // Riferimenti elementi UI
    const clockEl = document.getElementById('lumen-clock');
    const greetingEl = document.getElementById('lumen-greeting');
    const searchInput = document.getElementById('lumen-search-input');
    const searchSubmit = document.getElementById('lumen-search-submit');
    const favoritesGrid = document.getElementById('lumen-favorites-grid');

    // Modal impostazioni
    const modal = document.getElementById('lumen-settings-modal');
    const toggleSettingsBtn = document.getElementById('lumen-toggle-settings');
    const closeSettingsBtn = document.getElementById('close-settings');
    const saveSettingsBtn = document.getElementById('save-settings');

    const nameInput = document.getElementById('user-name');
    const sitesTextarea = document.getElementById('favorite-sites');
    const themeButtons = document.querySelectorAll('.theme-btn');

    // 1. Orologio in tempo reale
    function updateClock() {
        const now = new Date();
        clockEl.textContent = now.toLocaleTimeString();
    }
    setInterval(updateClock, 1000);
    updateClock();

    // 2. Carica impostazioni salvate
    function loadSettings() {
        chrome.storage.sync.get(['userName', 'selectedTheme', 'favoriteSites'], (data) => {
            const name = data.userName || 'Amico';
            const hour = new Date().getHours();
            let timeGreeting = 'Buongiorno';
            if (hour >= 13 && hour < 18) timeGreeting = 'Buon pomeriggio';
            else if (hour >= 18) timeGreeting = 'Buonasera';

            greetingEl.textContent = `${timeGreeting}, ${name}! ☀️`;
            nameInput.value = data.userName || '';

            // Applica tema
            const theme = data.selectedTheme || 'light';
            document.body.className = `theme-${theme}`;
            themeButtons.forEach(btn => {
                btn.classList.toggle('active', btn.dataset.theme === theme);
            });

            // Siti preferiti di default se vuoti
            const defaultSites = "Google | https://google.com\nGitHub | https://github.com\nYouTube | https://youtube.com\nReddit | https://reddit.com";
            sitesTextarea.value = data.favoriteSites !== undefined ? data.favoriteSites : defaultSites;

            renderFavorites(sitesTextarea.value);
        });
    }

    // 3. Renderizza i preferiti nella griglia
    function renderFavorites(text) {
        favoritesGrid.innerHTML = '';
        const lines = text.split('\n');
        lines.forEach(line => {
            if (!line.trim()) return;
            const parts = line.split('|');
            const title = parts[0] ? parts[0].trim() : 'Sito';
            const url = parts[1] ? parts[1].trim() : (parts[0] ? parts[0].trim() : '#');

            const finalUrl = url.startsWith('http') ? url : `https://${url}`;

            const tile = document.createElement('a');
            tile.className = 'lumen-tile';
            tile.href = finalUrl;
            tile.textContent = title;
            favoritesGrid.appendChild(tile);
        });
    }

    // 4. Motori di ricerca
    document.querySelectorAll('.search-selector-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.search-selector-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            currentEngine = e.target.dataset.theme || e.target.dataset.engine;
        });
    });

    function performSearch() {
        const query = searchInput.value.trim();
        if (!query) return;

        let searchUrl = '';
        if (query.startsWith('http://') || query.startsWith('https://') || query.includes('.')) {
            searchUrl = query.startsWith('http') ? query : `https://${query}`;
        } else {
            if (currentEngine === 'bing') {
                searchUrl = `https://www.bing.com/search?q=${encodeURIComponent(query)}`;
            } else if (currentEngine === 'duckduckgo') {
                searchUrl = `https://duckduckgo.com/?q=${encodeURIComponent(query)}`;
            } else {
                searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
            }
        }
        window.location.href = searchUrl;
    }

    searchSubmit.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch();
    });

        // 5. Gestione Modale Impostazioni
        toggleSettingsBtn.addEventListener('click', () => modal.classList.remove('hidden'));
        closeSettingsBtn.addEventListener('click', () => modal.classList.add('hidden'));

        themeButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                themeButtons.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                document.body.className = `theme-${e.target.dataset.theme}`;
            });
        });

        saveSettingsBtn.addEventListener('click', () => {
            const activeThemeBtn = document.querySelector('.theme-btn.active');
            const selectedTheme = activeThemeBtn ? activeThemeBtn.dataset.theme : 'light';

            chrome.storage.sync.set({
                userName: nameInput.value.trim(),
                                    selectedTheme: selectedTheme,
                                    favoriteSites: sitesTextarea.value
            }, () => {
                modal.classList.add('hidden');
                loadSettings();
            });
        });

        loadSettings();
});
